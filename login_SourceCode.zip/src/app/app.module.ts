import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegistrationFormComponent } from './registration-form/registration-form.component';
import { Injector } from '@angular/core';
import { createCustomElement } from '@angular/elements';

@NgModule({
  declarations: [AppComponent, RegistrationFormComponent],
  imports: [BrowserModule, AppRoutingModule, ReactiveFormsModule],
  providers: [],
  // bootstrap: [AppComponent, RegistrationFormComponent],
  entryComponents: [RegistrationFormComponent],
})
export class AppModule {
  ngDoBootstrap() {}

  constructor(private injector: Injector) {
    const el = createCustomElement(RegistrationFormComponent, {
      injector: this.injector,
    });
    customElements.define('login-form', el);
  }
}
