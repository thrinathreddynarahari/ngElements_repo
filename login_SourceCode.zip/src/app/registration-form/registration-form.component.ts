import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormControlName, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-registration-form',
  templateUrl: './registration-form.component.html',
  styleUrls: ['./registration-form.component.css']
})
export class RegistrationFormComponent implements OnInit {

  constructor() { }
  registrationForm!:FormGroup;
  @Input() image="./assets/login-webcomponent.png";

  @Output() val=new EventEmitter();

  ngOnInit(): void {
    this.registrationForm=new FormGroup({         
      email:new FormControl("",[Validators.required,Validators.minLength(10),Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
      password: new FormControl("",[Validators.required,Validators.minLength(8),Validators.maxLength(15)])
    })
  }
  onsubmit(){
    console.log(this.registrationForm);
    if(this.registrationForm.status==="INVALID"){
      this.registrationForm.markAllAsTouched()
    }
    else{
      this.val.emit(this.registrationForm);
    }
    
    
  }

}
